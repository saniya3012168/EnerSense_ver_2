# EnerSense

Energy optimization and clean energy adoption platform.

## Setup
```bash
pip install -r requirements.txt
python app.py
```
